<?php
require_once '../web_db/multi_values.php';
$obj = new multi_values();
$tot= $obj->get_total_milk_toPay();
echo $tot;

 
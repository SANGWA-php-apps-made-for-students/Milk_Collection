<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_delivery'])) {

    $date = date("Y-m-d");
    $profile = $_POST['txt_profile_id'];
    $account = $_POST['txt_account_id'];
    $milk = $_POST['txt_milk_id'];
    
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_delivery($date, $profile, $account, $milk);
}
?>

<html>
    <head>
        <title>
            delivery</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_delivery.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
            <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
            <input type="hidden" id="txt_milk_id"      name="txt_milk_id"/>
            <?php
            include 'header_menu.php';
            ?>
         
            <div class="parts eighty_centered">
                <div class="parts eighty_centered ">  delivery</div>
                <table class="new_data_table">
                    <tr><td>profile :</td><td> <?php get_profile_combo(); ?>  </td></tr>
                    <tr><td>account :</td><td> <?php get_account_combo(); ?>  </td></tr> 
                    <tr><td>milk :</td><td> <?php get_milk_combo(); ?>  </td></tr>

                    <tr><td colspan="2"> <input type="submit" class="button" name="send_delivery" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered" >
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->list_delivery();
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_profile_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_profile_in_combo();
}

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function get_milk_combo() {
    $obj = new multi_values();
    $obj->get_milk_in_combo();
}

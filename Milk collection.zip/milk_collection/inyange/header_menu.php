<div class="parts  no_paddin_shade_no_Border full_center_two_h bg_theme margin_free ">
 
    <div class="parts seventy_centered no_paddin_shade_no_Border   heit_free " id="my_title">
        <div class="parts two_fifty_right heit_free whilte_text">
            <?php echo 'Welcome Dear,   ' . $_SESSION['names'] . ' - ' . $_SESSION['cat']; ?>
        </div>
    </div> 
    <div class="parts menu skin no_shade_noBorder reverse_border bg_theme bg_theme2 margin_free full_center_two_h heit_free">
        <a href="inyange_dashboard.php">Home</a>
        <a href="new_export.php">Received Milk</a>
       
        <a href="new_payments.php">Payments</a>
        <a href="new_milk.php">Price setting</a>
        <div class="parts margin_free two_fifty_right heit_free no_paddin_shade_no_Border">
            <a href="../logout.php">Logout</a>
        </div>
    </div>
</div>
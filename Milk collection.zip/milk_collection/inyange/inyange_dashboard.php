<?php
session_start();
?><!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <form action="inyange_dashboard.php" method="post">
            <?php
            include 'header_menu.php';
            ?>
            <div class="eighty_centered">
                <h1>Inyange Administration dashboard</h1>
                <div class="parts no_shade_noBorder">
                    <p>Dear Admin,</p>
                    <ul>
                        <li>  here are the features your can manage.<br/>
                            With fact that you receive milk, you can confirm the received milk and 
                            specify the paid amount.</li>
                        <li>
                            You can add set unit price of milk.
                        </li>
                    </ul>
                </div>
                <div class="parts two_fifty_right heit_free no_shade_noBorder">
                    <h2>Address</h2>
                </div>
            </div>
        </div>
    </form>
</body>
</html>

<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_payments'])) {
    $date = date("Y-m-d");
    $amount_due = $_POST['txt_amount_due'];
    $amount_paid = $amount_due;
    $amount_remaining = $amount_due - $amount_paid;
    $pay_type = $_SESSION['cat'];
    $number_litters = $_POST['txt_number_litters'];
    require_once '../web_db/new_values.php';

    $obj = new new_values();
    $obj->new_payments($date, $amount_due, $amount_paid, $amount_remaining, $pay_type, $number_litters, 0);
}
?>

<html>
    <head>
        <title>
            payments</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_payments.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_total_price"   name="txt_university_id"/>

            <?php
            include 'header_menu.php';
            ?> 

            <div class="parts eighty_centered">
                <div class="parts eighty_centered ">  payments</div> 
                <div class="parts two_fifty_right no_shade_noBorder">
                    <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                        Total milk to pay
                    </div>
                    <div class="parts xx_titles" id="inyange_total_milk">

                    </div>
                </div>



                <table class="new_data_table">     
                    <tr><td>Number litters :</td><td> <input type="number" id="txt_number_litters"     name="txt_number_litters" required class="textbox" />
                            <a style="color: #000066" href="#" id="enable_link">Amount</a> 
                            <span id="price_display" class="off"></span>
                        </td></tr>
                    <tr><td>amount_due :</td><td> <input type="text"         class="disabled_txt"  disabled="false" id="txt_amount_due" name="txt_amount_due" required class="textbox" />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_payments" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered" >
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->list_payments_inyange();
                ?>

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_pay_type_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_pay_type_in_combo();
}

<?php
session_start();
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_export'])) {
    echo 'My category is: ' . $_SESSION['cat'];
    $export_date = date("Y-m-d1;");
    $quantity = $_POST['txt_quantity'];
    $account = $_POST['txt_account_id'];
    $receiver = $_SESSION['userid1;'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_export($export_date, $quantity, $account, $receiver);
}
?>

<html>
    <head>
        <title>
            export</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_export.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_account_id"   name="txt_university_id"/><input type="hidden" id="txt_receiver_id"   name="txt_university_id"/>
            <?php
            include 'header_menu.php';
            ?>
            <div class="parts eighty_centered">
                Here are the data imported from Dairy center
            </div>
            <div class="parts eighty_centered no_paddin_shade_no_Border heit_free" >
                <div class="parts full_center_two_h heit_free">
                    <table><tr>
                            <td>
                            <td> <?php
                                require_once '../web_db/multi_values.php';
                                $obj = new multi_values();
                                $obj->get_unconfirmed_export();
                                ?></td>
                            <td> 
                        </tr>
                        <tr>
                            <td></td>
                            <td><strong>  Received Quantity</strong></td>
                        </tr>
                        <tr><td></td><td>
                            <?php
                            require_once '../web_db/multi_values.php';
                            $obj = new multi_values();
                            $obj->get_confirmed_export();
                            ?>

                            </td>
                        </tr>

                    </table>
                </div>


            </div>  


        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <div class="parts full_center_two_h heit_free  footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_account_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function get_receiver_combo() {

    $obj = new multi_values();
    $obj->get_account_in_combo();
}


<div class="parts ninenty_centered no_paddin_shade_no_Border">
    
    <div class="parts seventy_centered no_shade_noBorder" id="my_title">

    </div>
    
</div>
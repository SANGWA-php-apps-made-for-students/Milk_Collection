<?php
session_start();
if (!isset($_SESSION['login_token'])) {
//    header('location: ../logout.php');
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
        include './header_menu.php';
        ?>
    </body>
</html>

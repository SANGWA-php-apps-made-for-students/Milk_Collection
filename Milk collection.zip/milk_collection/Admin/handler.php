<?php

session_start();
if (isset($_POST['cbo_account_category'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_category_id_by_account_category_name($_POST['cbo_account_category']);
    return $id;
}
if (isset($_POST['cbo_profile'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_id_by_profile_name();
    return $id;
}
if (isset($_POST['cbo_profile'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_id_by_profile_name();
    return $id;
}if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name();
    return $id;
}
if (isset($_POST['cbo_milk'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_milk_id_by_milk_name();
    return $id;
}
if (isset($_POST['cbo_pay_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_pay_type_id_by_pay_type_name();
    return $id;
}
if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name();
    return $id;
}
if (isset($_POST['cbo_receiver'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_receiver_id_by_receiver_name();
    return $id;
}
if (isset($_POST['cbo_name'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_name_id_by_name_name();
    return $id;
}
if (isset($_POST['cbo_last_name'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_last_name_id_by_last_name_name();
    return $id;
}
if (isset($_POST['get_milk_price'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_milk_price($_POST['get_milk_price']);
    return $id;
}
//inyange
if (isset($_POST['exp_id'])) {
    try {
        $exp_id = $_POST['exp_id'];
        $user = $_SESSION['userid'];
        require_once '../web_db/updates.php';
        $obj = new updates();
        $id = $obj->get_export_updated($user, $exp_id);
        echo 'Confirmed';
    } catch (Exception $ex) {
        echo $ex;
    }
}
if (isset($_POST['date_chosen'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $date_chosen = $_POST['date_chosen'];
    $profile_id = $_POST['profile_id'];
    $id = $obj->get_delivery_by_agent($profile_id, $date_chosen);
    return $id;
}
if (isset($_POST['only_date_chosen'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_delivery_by_date($_POST['only_date_chosen']);
}
if (isset($_POST['only_month_chosen'])) {
      require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_delivery_by_month($_POST['only_month_chosen']);
}
if (isset($_POST['only_year_chosen'])) {
     require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_delivery_by_year($_POST['only_year_chosen']);

    return $id;
}
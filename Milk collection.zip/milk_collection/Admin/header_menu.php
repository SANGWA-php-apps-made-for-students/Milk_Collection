<div class="parts  no_paddin_shade_no_Border full_center_two_h bg_theme margin_free ">

    <div class="parts logo  left_off_eighty"style=" margin-left: 50px;width: 100px; height: 100px;">
    </div>
    <div class="parts seventy_centered no_paddin_shade_no_Border   heit_free " id="my_title">
        <div class="parts two_fifty_right heit_free whilte_text">
            <?php echo 'Welcome Dear,   ' . $_SESSION['names'] . ' - ' . $_SESSION['cat']; ?>
        </div>
    </div> 
    <div class="parts menu skin no_shade_noBorder reverse_border bg_theme bg_theme2 margin_free full_center_two_h heit_free">
        <a href="Admin_dashboard.php">Home</a>
        <a href="new_account.php">User accounts</a>
        <a href="new_account_category.php">Accounts categories</a>
        <a href="new_delivery.php">Delivery</a>
        <a href="new_export.php">Exports</a>
        <a href="new_milk.php">Milk</a>
        <a href="new_payments.php">Payments</a>
        <div class="parts margin_free two_fifty_right heit_free no_paddin_shade_no_Border">
            <a href="../logout.php">Logout</a>
        </div>
    </div>
</div>
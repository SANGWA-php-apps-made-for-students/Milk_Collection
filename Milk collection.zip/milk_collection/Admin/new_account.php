<?php
include '../web_db/multi_values.php';
$obj_mul = new multi_values();
$last_profile = $obj_mul->get_last_profileid();
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_account'])) {
    $name = $_POST['txt_name'];
    $last_name = $_POST['txt_lastname'];
    $gender = $_POST['txt_gender'];
    $telphone = $_POST['txt_telphone'];
    require_once '../web_db/new_values.php';

    $obj = new new_values();
    $obj_mul = new multi_values();
    $obj->new_profile($name, $last_name, $gender, $telphone);
    require_once '../web_db/connection.php';
    $db = new dbconnection();
    $sql = "select   profile.profile_id from profile order by profile_id desc limit 1";
    $stmt = $db->openConnection()->prepare($sql);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['profile_id'];

    $username = $_POST['txt_username'];
    $password = $_POST['txt_password'];
    $account_category = $_POST['txt_account_category_id'];
    $obj->new_account($username, $password, $account_category, $userid);
}
?>
<html>
    <head>
        <title>
            account</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_account.php" method="post" enctype="multipart/form-data">
            <input type="hidden" id="txt_account_category_id"   name="txt_account_category_id"/>
            <input type="hidden" id="txt_profile_id"   name="txt_university_id"/>
            <?php
            include 'header_menu.php';
            ?>

            <div class="parts eighty_centered">
                account saved successfully!</div>

            <div class="parts eighty_centered">
                <div class="parts eighty_centered ">account</div>
                <table class="new_data_table">
                    <tr><td>name :</td><td><input type="text"     name="txt_name" required class="textbox" />  </td></tr> <tr><td>last_name :</td><td> 
                            <input type="text"     name="txt_lastname" required class="textbox" /> </td></tr><tr><td>gender :</td><td>
                            <select name="txt_gender">
                                <option>
                                    Male
                                </option>
                                <option>
                                    Female
                                </option>
                            </select>  </td></tr>
                    <tr><td>Telephone :</td><td> <input type="text"     name="txt_telphone" required class="textbox" />  </td></tr>
                    <tr><td>username :</td><td> <input type="email"     name="txt_username" required class="textbox" />  </td></tr>
                    <tr><td>password :</td><td> <input type="text"     name="txt_password" required class="textbox" />  </td></tr>
                    <tr><td>account_category :</td><td> <?php get_account_category_combo(); ?>  </td></tr> 

                    <tr><td colspan="2"> <input type="submit" class="button" name="send_account" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered" >
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->list_account();
                ?>
            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php
function get_account_category_combo() {
    $obj = new multi_values();
    $obj->get_account_category_in_combo();
}

function get_profile_combo() {

    $obj = new multi_values();
    $obj->get_profile_in_combo();
}

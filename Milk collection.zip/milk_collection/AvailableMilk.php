<?php
require_once('web_db/connection.php');
$db = new dbconnection();
$sql = " select sum(delivery.quantity)as qty  from delivery ";
$stmt = $db->openConnection()->prepare($sql);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);
$userid = $row['qty'];

$sql2 = " select sum(export.quantity)as qty2  from export ";
$stmt2 = $db->openConnection()->prepare($sql2);
$stmt2->execute();
$row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
$userid2 = $row2['qty2'];
$diff = $userid - $userid2;
echo $diff;

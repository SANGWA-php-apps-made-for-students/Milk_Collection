$(document).ready(function () {
    try {
        get_account_category_id_combo();
        get_profile_id_combo();
        get_account_id_combo();
        get_milk_id_combo();
        get_pay_type_id_combo();
        get_account_id_combo();
        get_receiver_id_combo();
        get_name_id_combo();
        get_last_name_id_combo();
        get_paymeny_enabled();

        //inyange
        get_inyange_confirm_link();
        get_available_milk();
        show_agents_list();
        select_agent_link_clicked();
        choose_existing_delivery();
        choose_new_delivery();
        get_milk_to_pay();
        select_agent_link_clicked();
        get_delivery_by_date();
        select_link_search();
        get_delivery_by_month();
        display_farmer();
    } catch (err) {
        alert(err.message);
    }
});
function get_account_category_id_combo() {
    try {
        $('.cbo_account_category').change(function () {
            var cbo_account_category = $('.cbo_account_category option:selected').text();
            $.post('../Admin/handler.php', {cbo_account_category: cbo_account_category}, function (data) {
                $('#txt_account_category_id').val(data);
                alert(data);
            });

        });
    } catch (err) {
        alert(err.message);
    }
}
function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').text();
            $.post('../Admin/handler.php', {cbo_profile: cbo_profile}, function (data) {
                $('#txt_profile_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').text();
            $.post('../Admin/handler.php', {cbo_account: cbo_account}, function (data) {
                $('#txt_account_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_milk_id_combo() {
    try {
        $('.cbo_milk').change(function () {
            var cbo_milk = $('.cbo_milk option:selected').text();
            $.post('../Admin/handler.php', {cbo_milk: cbo_milk}, function (data) {
                $('#txt_milk_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_pay_type_id_combo() {
    try {
        $('.cbo_pay_type').change(function () {
            var cbo_pay_type = $('.cbo_pay_type option:selected').text();
            $.post('../Admin/handler.php', {cbo_pay_type: cbo_pay_type}, function (data) {
                $('#txt_pay_type_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').text();
            $.post('../Admin/handler.php', {cbo_account: cbo_account}, function (data) {
                $('#txt_account_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_receiver_id_combo() {
    try {
        $('.cbo_receiver').change(function () {
            var cbo_receiver = $('.cbo_receiver option:selected').text();
            $.post('../Admin/handler.php', {cbo_receiver: cbo_receiver}, function (data) {
                $('#txt_receiver_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_name_id_combo() {
    try {
        $('.cbo_name').change(function () {
            var cbo_name = $('.cbo_name option:selected').text();
            $.post('../Admin/handler.php', {cbo_name: cbo_name}, function (data) {
                $('#txt_name_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
function get_last_name_id_combo() {
    try {
        $('.cbo_last_name').change(function () {
            var cbo_last_name = $('.cbo_last_name option:selected').text();
            $.post('../Admin/handler.php', {cbo_last_name: cbo_last_name}, function (data) {
                $('#txt_last_name_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}
//this function has two events
function get_paymeny_enabled() {
    var the_due = 0;
    $('#enable_link').unbind('click').click(function () {
        var get_milk_price = $('#txt_number_litters').val();
        if (get_milk_price !== 0 && get_milk_price !== '') {
            $.post('../Admin/handler.php', {get_milk_price: get_milk_price}, function (data) {
                $('#price_display').html(data);
                $('#txt_amount_due').val($('#price_display').text());
                $('.disabled_txt').removeAttr('disabled');
                the_due = $('#price_display').text();
            });
        } else {
            alert('You have to specify the number of litters');
        }
        return false;
    });

    $('#txt_amount_paid').keyup(function () {
        var remaining = 0;
        var paid = $(this).val();
        remaining = the_due - paid;
        $('#txt_remaining').val(remaining);
    });


}
//inyange confirm
function get_inyange_confirm_link() {
    $('.inyange_confirm_link').click(function () {
        var exp_id = $(this).attr('value');
        $.post('../Admin/handler.php', {exp_id: exp_id}, function (data) {
            alert(data);
        });
        return false;
    });
}
function get_available_milk() {
    setTimeout(function () {
        $('#milk_amount').load('../AvailableMilk.php');
        get_available_milk();
    }, 1000);
}
function show_agents_list() {
    $('#show_agent').click(function () {
        $('#dialog_students').show(300);
        $('#dialog_child_agents').fadeIn(300);
    });
}
function hide_dialog() {
    $('#dialog_students').click(function () {
        $('#dialog_child').fadeOut(300);
        $('#dialog_child_agents').hide(300);

    });
}
function select_agent_link_clicked() {
    $('.select_link_agents').click(function () {
        var student_id = $(this).attr('value').trim();
        $('#txt_agent_id2').val(student_id);
        $('#dialog_students').hide(300);
        $('#dialog_child_agents').fadeOut(300);
    });
}
function choose_new_delivery() {
    $('#new_delvery_choice').click(function () {
        $('#table_tohide').slideDown();
        $('#agent_link_hider').hide(200);
    });
}
function choose_existing_delivery() {
    $('#exisiting_delvery_choice').click(function () {
        $('#table_tohide').slideUp();
        $('#agent_link_hider').show(200);
    });
}

function get_milk_to_pay() {
    setTimeout(function () {
        $('#inyange_total_milk').load('../inyange/total_milk_toPay.php');
        get_milk_to_pay();
    }, 1000);

}//this is the amount of milk that inyange has to pay

//these two funcions a re for the report page
function select_link_search() {
    $('.select_link_search').click(function () {
        try {
            var profile_id = $(this).closest('td').siblings('.profile_col').text().trim();
            var profile_name = $(this).closest('td').siblings('.f_name_col').text().trim();
            var profile_surname = $(this).closest('td').siblings('.f_surname_col').text().trim();
            $('#selected_dispaly').html(profile_name+'  '+profile_surname);
            $('#txt_profile_id').val(profile_id);

        } catch (err) {
            alert(err.message);
        }
        return false;
    });

}
function get_delivery_by_date() {
    try {
        $('#btn_serch_by_date').click(function () {
            var profile_id = $('#txt_profile_id').val();
            if (profile_id != '') {
                var date_chosen = $('#datePick').val();
                $.post('../Admin/handler.php', {profile_id: profile_id, date_chosen: date_chosen}, function (data) {
                    if (data != '') {
                        $('#dialog_child_delivery_search').html(data);
                    }
                });

            } else {
                var only_date_chosen = $('#datePick').val();
                $.post('../Admin/handler.php', {only_date_chosen: only_date_chosen}, function (data) {
                    if (data != '') {
                        $('#dialog_child_delivery_search').html(data);
                    }
                });
            }
            $('#dialog_child_delivery_search').slideDown(300);
            $('#farmer_box').slideUp(300);
            return false;
        });

    } catch (err) {
        alert(err.message);
    }
}
function get_delivery_by_month() {
    $('#btn_serch_by_month').click(function () {
        var date = $('#datePick').datepicker('getDate'),
                day = date.getDate(),
                only_month_chosen = date.getMonth() + 1;
        $.post('../Admin/handler.php', {only_month_chosen: only_month_chosen}, function (data) {
            if (data != '') {
                $('#dialog_child_delivery_search').html(data);
            }
        });
        $('#dialog_child_delivery_search').slideDown(300);
        $('#farmer_box').slideUp(300);
    });
    $('#btn_serch_by_year').click(function () {
        var date = $('#datePick').datepicker('getDate'),
                day = date.getDate(),
                year = date.getFullYear();
        var only_year_chosen = year;
        $.post('../Admin/handler.php', {only_year_chosen: only_year_chosen}, function (data) {
            if (data != '') {
                $('#dialog_child_delivery_search').html(data);
            }
        });
        $('#dialog_child_delivery_search').slideDown(300);
        $('#farmer_box').slideUp(300);
    });

}
function display_farmer() {
    $('#bring_back_farmer').click(function () {
        $('#dialog_child_delivery_search').slideUp(300);
        $('#farmer_box').slideDown(300);
    });
}

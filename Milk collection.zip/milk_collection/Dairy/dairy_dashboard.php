<?php
    session_start();
?><!DOCTYPE html>
 
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <?php
         include './header_menu.php';
        ?>
         <div class="eighty_centered">
                <h1>Distributor Administration dashboard</h1>
                <div class="parts  eighty_centered no_shade_noBorder">
                    <p>Dear Admin,</p>
                    <ul>
                        <li> You can register people who are delivering milk.</li>
                        <li>
                           Add milk deliveries from agents to the system.
                        </li>
                        <li>
                          Pay agents who delivered milk.
                        </li>
                        <li>
                          Export all received milk to INYANGE main dairy.
                        </li>
                    </ul>
                </div>
            </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
    </body>
</html>

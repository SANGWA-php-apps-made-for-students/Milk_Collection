<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_delivery'])) {

    $date = date("Y-m-d");
    $name = $_POST['txt_name'];
    $last_name = $_POST['txt_lastname'];
    $gender = $_POST['txt_gender'];
    $telphone = $_POST['txt_telphone'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_profile($name, $last_name, $gender, $telphone);
//Last profile
    require_once '../web_db/connection.php';
    $db = new dbconnection();
    $sql = "select   profile.profile_id from profile order by profile_id desc limit 1";
    $stmt = $db->openConnection()->prepare($sql);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $userid = $row['profile_id'];

//account       
    $account = $_SESSION['userid'];
    $milk = '1';
    $acc = $_SESSION['userid'];
    $quantity = $_POST['txt_quantity'];
    $agent = $userid;
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $obj->new_delivery($date, $userid, $acc, $milk, $quantity, $agent);
}
if (isset($_POST['send_existing'])) {
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    $quantity = $_POST['txt_quantity2'];
    $agent = $_POST['txt_agent_id2'];
    $milk = '1';
    $acc = $_SESSION['userid'];
    $date = date("Y-m-d");
    if (!empty($agent)) {
        $obj->new_delivery($date, $agent, $acc, $milk, $quantity, $agent);
    } else {
        ?>
        <script>
            alert('You have to select  a farmer');
        </script>
        <?php
    }
}
?>
<html>
    <head>
        <title>
            delivery</title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>  
    <body>

        <div class=" parts abs_full accept_abs off " style=" "  id="dialog_students">
        </div>
        <div class="parts x_height_4x seventy_centered abs_child left_off_seventy  heit_free off" style="overflow-y: scroll;  position: fixed; background-color: #fff; opacity: 1;" id="dialog_child_agents">
            <?php
            require_once '../web_db/multi_values.php';
            $obj_mul = new multi_values();
            $obj_mul->get_selectable_profile();
            ?>
        </div>
        <?php
        include 'header_menu.php';
        ?>
        <div class="parts eighty_centered heit_free no_paddin_shade_no_Border">
            <div class="parts" id="new_delvery_choice">New farmer</div>
            <div class="parts" id="exisiting_delvery_choice">Existing farmer</div>
        </div>
        <div class="parts eighty_centered">
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border">
                <form action="new_delivery.php" method="post">
                    <input type="hidden" id="txt_agent_id2"      name="txt_agent_id2"/>
                    <div class="parts off" id="agent_link_hider">
                        <table>
                            <tr>
                                <td>Agent</td>
                                <td> <a href="#" id="show_agent" style="color: #000066;">Choose an agent</a>  </td>
                            </tr>
                            <tr>
                                <td>Amount Litters</td>  
                                <td><input type="text" class="textbox" required name="txt_quantity2"></td>

                            </tr>
                            <tr>
                                <td> &nbsp;</td>  
                                <td><input type="submit" value="Confirm"  name="send_existing"></td>

                            </tr>
                        </table>
                    </div>
                </form>
            </div>
            <form action="new_delivery.php" method="post" enctype="multipart/form-data">
                <input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
                <input type="hidden" id="txt_account_id"   name="txt_account_id"/>
                <input type="hidden" id="txt_milk_id"      name="txt_milk_id"/>
                <input type="hidden" id="txt_agent_id"      name="txt_milk_id"/>
                <div class="parts off" id="table_tohide" >
                    <div class="parts eighty_centered ">  delivery</div>
                    <table class="new_data_table" style="margin-top: 0px;">
                        <tr><td>Name:</td><td>  <input type="text" class="textbox" name="txt_name"></td></tr>
                        <tr><td>Last name:</td><td>  <input type="text" class="textbox" name="txt_lastname"></td></tr>
                        <tr><td>Gender:</td> <td> <select name="txt_gender">
                                    <option></option>
                                    <option>Male</option>
                                    <option>Female</option>
                                </select></td>
                        <tr><td>Telephone:</td><td>  <input type="text" class="textbox" name="txt_telphone"></td></tr>
                        <tr><td>Quantity:</td><td>  <input type="text" class="textbox" value="0" name="txt_quantity"></td></tr>
                        <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_delivery" value="Save"/>  </td></tr>
                    </table>
                </div>
                <div class="parts eighty_centered no_paddin_shade_no_Border" >
                    <?php
                    require_once '../web_db/multi_values.php';
                    $obj = new multi_values();
                    $obj->get_grouped_delivery();
                    ?>
                </div> 
        </div>

        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <div class="parts eighty_centered "> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php
function get_profile_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_profile_in_combo();
}

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function get_milk_combo() {
    $obj = new multi_values();
    $obj->get_milk_in_combo();
}

<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
?>
<html>
    <head>
        <title>
            delivery
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.structure.min.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.theme.css" rel="stylesheet" type="text/css"/>
        <link href="date_picker/jquery-ui.theme.min.css" rel="stylesheet" type="text/css"/>
    </head>  
    <body>
        <input type="text" class="off" name="txt_profile_id" id="txt_profile_id">
        <?php
        include 'header_menu.php';
        ?>
        <div class="parts eighty_centered heit_free no_paddin_shade_no_Border">
            <table>
                <tr>
                    <td>Pick the date:</td>
                    <td>    <input type="text" class="textbox  heit_free" style="float: left;" id="datePick" />  
                    </td>
                    <td>                                               
                        <input type="button"  id="btn_serch_by_year" style="margin-left: 50px;" class="confirm_buttons  " value="Search by year">
                        <input type="button"  id="btn_serch_by_month" style="margin-left: 50px;" class="confirm_buttons  " value="Search by month">
                        <input type="button"  id="btn_serch_by_date" style="margin-left: 50px;" class="confirm_buttons  " value="Search by date"> 
                    </td>
                </tr>
            </table>
        </div>
        <div class="parts eighty_centered no_paddin_shade_no_Border">
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="notifications">
                <div class="parts " id="bring_back_farmer">
                    View farmer
                </div>
                <span class="parts no_shade_noBorder" id="selected_dispaly">
                    
                </span>
            </div>
            <div class="parts full_center_two_h heit_free no_paddin_shade_no_Border" id="dialog_child_delivery_search">

            </div>
            <div class="parts no_paddin_shade_no_Border" id="farmer_box">
                <?php
                require_once '../web_db/multi_values.php';
                $obj_mul = new multi_values();
                $obj_mul->get_selectable_profile_for_search();
                ?>
            </div>
        </div>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.js" type="text/javascript"></script>
        <script src="date_picker/jquery-ui.min.js" type="text/javascript"></script>
        <script>
            $('#datePick').datepicker({dateFormat: 'yy-mm-dd'});
        </script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_profile_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_profile_in_combo();
}

function get_account_combo() {
    $obj = new multi_values();
    $obj->get_account_in_combo();
}

function get_milk_combo() {
    $obj = new multi_values();
    $obj->get_milk_in_combo();
}

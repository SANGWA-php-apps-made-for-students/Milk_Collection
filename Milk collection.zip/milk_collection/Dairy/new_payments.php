<?php
if (!isset($_SESSION)) {
    session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
}
if (isset($_POST['send_payments'])) {
    $date = date("Y-m-d");
    $amount_due = $_POST['txt_amount_due'];
    $amount_paid = $_POST['txt_amount_paid'];
    $amount_remaining = $_POST['txt_amount_remaining'];
    $pay_type = $_SESSION['cat'];
    $number_litters = $_POST['txt_number_litters'];
    $agent_id = $_POST['txt_agent_id'];
    require_once '../web_db/new_values.php';
    $obj = new new_values();
    if (!empty($agent_id)) {
          $obj->new_payments($date, $amount_due, $amount_paid, $amount_remaining, $pay_type, $number_litters, $agent_id);
    }else{
        ?>
        <script>
            alert('You ahve to select an a farmer');
        </script>
        <?php
    }
  
}
?>

<html>
    <head>
        <title>
            payments
        </title>
        <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/>
    </head>  
    <body>
        <form action="new_payments.php" method="post" enctype="multipart/form-data">
            <div class=" parts abs_full accept_abs off " style=" "  id="dialog_students">
            </div>
            <div class="parts x_height_4x seventy_centered abs_child left_off_seventy  heit_free off" style="overflow-y: scroll;  position: fixed; background-color: #fff; opacity: 1;" id="dialog_child_agents">
                <?php
                require_once '../web_db/multi_values.php';
                $obj_mul = new multi_values();
                $obj_mul->get_selectable_profile();
                ?>
            </div>
            <input type="hidden" id="txt_total_price"   name="txt_university_id"/>
            <?php
            include 'header_menu.php';
            ?>
            <div class="parts eighty_centered">
                <div class="parts eighty_centered ">  payments</div>
                <table class="new_data_table">    
                    <tr>
                        <td>
                            Agent
                        </td>
                        <td>
                            <a href="#" id="show_agent" style="color: #000066;">Choose an agent</a> 
                            <input type="hidden" id="txt_agent_id2"      name="txt_agent_id"/>
                        </td>
                    </tr>
                    <tr><td>Number litters :</td><td> <input type="number" id="txt_number_litters"     name="txt_number_litters" required class="textbox" />
                            <a style="color: #000066" href="#" id="enable_link">Amount</a> 
                            <span id="price_display" class="off"></span>
                        </td></tr>
                    <tr><td>amount_due :</td><td> <input type="text"         class="disabled_txt"  disabled="false" id="txt_amount_due" name="txt_amount_due" required class="textbox" />  </td></tr>
                    <tr><td>amount_paid :</td><td> <input type="text"   id="txt_amount_paid"     class="disabled_txt"  disabled="false"   name="txt_amount_paid" required class="textbox" />  </td></tr>
                    <tr><td>amount_remaining :</td><td> <input type="text" id="txt_remaining"  name="txt_amount_remaining" required class="textbox" />  </td></tr>
                    <tr><td colspan="2"> <input type="submit" class="confirm_buttons" name="send_payments" value="Save"/>  </td></tr>
                </table>
            </div>

            <div class="parts eighty_centered" >
                <?php
                require_once '../web_db/multi_values.php';
                $obj = new multi_values();
                $obj->list_payments_dairy();
                ?>

            </div>  
        </form>
        <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
        <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>
        <div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
    </body>
</hmtl>
<?php

function get_pay_type_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_pay_type_in_combo();
}

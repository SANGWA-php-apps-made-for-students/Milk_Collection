<?php

class new_values {

    function new_account($username, $password, $account_category, $profile) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into account values(:account_id, :username,  :password,  :account_category,  :profile)");
        $stm->execute(array(':account_id' => 0, ':username' => $username, ':password' => $password, ':account_category' => $account_category, ':profile' => $profile ));
    }
    function new_account_category($name) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into account_category values(:account_category_id, :name)");
        $stm->execute(array(':account_category_id' => 0, ':name' => $name
        ));
    }

    function new_delivery($date, $profile, $account, $milk,$quantity,$agent) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into delivery values(:delivery_id, :date,  :profile,  :account,  :milk, :quantity,:agent)");
        $stm->execute(array(':delivery_id' => 0, ':date' => $date, ':profile' => $profile, ':account' => $account, ':milk' => $milk, ':quantity' => $quantity, ':agent' => $agent
        ));
    }

    function new_payments($date, $amount_due, $amount_paid, $amount_remaining, $pay_type, $txt_number_litters,$agent) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $stm = $db->prepare("insert into payments values(:payments_id, :date,  :amount_due,  :amount_paid,  :amount_remaining,  :pay_type,:number_litters, :agent)");
        $stm->execute(array(':payments_id' => 0, ':date' => $date, ':amount_due' => $amount_due, ':amount_paid' => $amount_paid, ':amount_remaining' => $amount_remaining, ':pay_type' => $pay_type, 'number_litters' => $txt_number_litters, 'agent' => $agent));
    }

    function new_pay_type($name) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into pay_type values(:pay_type_id, :name)");
        $stm->execute(array(':pay_type_id' => 0, ':name' => $name
        ));
    }

    function new_export($export_date, $quantity, $account, $receiver) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into export values(:export_id, :export_date,  :quantity,  :account,  :receiver)");
        $stm->execute(array(':export_id' => 0, ':export_date' => $export_date, ':quantity' => $quantity, ':account' => $account, ':receiver' => $receiver
        ));
    }

    function new_milk($cost_per_litter, $type) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into milk values(:milk_id, :cost_per_litter,  :type)");
        $stm->execute(array(':milk_id' => 0, ':cost_per_litter' => $cost_per_litter, ':type' => $type
        ));
    }

    function new_profile($name, $last_name, $gender, $telphone) {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();

        $stm = $db->prepare("insert into profile values(:profile_id, :name,  :last_name,  :gender,  :telphone)");
        $stm->execute(array(':profile_id' => 0, ':name' => $name, ':last_name' => $last_name, ':gender' => $gender, ':telphone' => $telphone
        ));
    }

}

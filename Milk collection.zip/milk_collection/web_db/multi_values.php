<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_account() {
        require_once '../web_db/connection.php';
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> username </td>
                    <td> password </td>
                    <td> account_category </td>
                    <td> Profile </td>
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['username']; ?>
                    </td>
                    <td>
                        <?php echo $row['password']; ?>
                    </td>
                    <td>
                        <?php echo $row['account_category']; ?>
                    </td>
                    <td>
                        <?php echo $row['profile']; ?>
                    </td>


                </tr>
            <?php } ?></table>
        <?php
    }

    function list_account_category() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account_category";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> name </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['name']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_delivery() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = " select   delivery.delivery_id,  delivery.date,     delivery.quantity,  profile.name,  profile.last_name,  profile.gender,  profile.telphone
                from delivery
                join profile on delivery.profile = profile.profile_id 
                join account on delivery.account = account.account_id";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> Delivery ID </td>
                    <td> Delivery date </td>

                    <td> Quantity </td>
                    <td> Name </td>
                    <td> Last name </td>
                    <td> Gender </td>
                    <td> Telephone </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>                        <?php echo $row['delivery_id']; ?>
                    </td>
                    <td>                        <?php echo $row['date']; ?>                    </td>
                    <td>                        <?php echo $row['quantity']; ?>                    </td>
                    <td>                        <?php echo $row['name']; ?>                    </td>
                    <td>                        <?php echo $row['last_name']; ?>                    </td>
                    <td>                        <?php echo $row['gender']; ?>                    </td>
                </td><td>                        <?php echo $row['telphone']; ?>                    </td>




            </tr>
        <?php } ?></table>
        <?php
    }

    function list_payments() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from payments";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> date </td>
                    <td> amount_due </td>
                    <td> amount_paid </td>
                    <td> amount_remaining </td>
                    <td> pay_type </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['amount_due']; ?>
                    </td>
                    <td>
                        <?php echo $row['amount_paid']; ?>
                    </td>
                    <td>
                        <?php echo $row['amount_remaining']; ?>
                    </td>
                    <td>
                        <?php echo $row['pay_type']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_payments_dairy() {
        require_once('../web_db/connection.php');
        $con = new dbconnection();
        $sql = "select   payments.payments_id,  payments.date,  payments.amount_due,  payments.amount_paid,  payments.amount_remaining,
             payments.number_litters,  profile.name,  profile.last_name
            from payments      join profile on profile.profile_id=payments.agent
                        where payments.pay_type=:pay_type";
        $agent = 'agent';
        $stmt = $con->openConnection()->prepare($sql);
        $stmt->execute(array(":pay_type" => $agent));
        ?>
        <table class="new_data_table">
            <thead><tr><td> payments_id </td><td> date </td><td> amount_due </td><td> amount_paid </td>
                    <td> amount_remaining </td> 
                    <td> number_litter </td>
                    <td> name </td><td> last_name </td>
                </tr></thead>
            <?php
            while ($row = $stmt->fetch()) {
                ?><tr> 
                    <td><?php echo $row['payments_id']; ?> </td>
                    <td><?php echo $row['date']; ?> </td>
                    <td><?php echo $row['amount_due']; ?> </td>
                    <td><?php echo $row['amount_paid']; ?> </td>
                    <td><?php echo $row['amount_remaining']; ?> </td>

                    <td><?php echo $row['number_litters']; ?> </td>
                    <td><?php echo $row['name']; ?> </td>
                    <td><?php echo $row['last_name']; ?> </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_payments_inyange() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from payments where pay_type='inyange'";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> Payment ID </td>
                    <td> date </td>
                    <td> amount_due </td>
                    <td> amount_paid </td>
                    <td> amount_remaining </td>
                    <td> pay_type </td>
                    <td> Quantity </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['payments_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['amount_due']; ?>
                    </td>
                    <td>
                        <?php echo $row['amount_paid']; ?>
                    </td>
                    <td>
                        <?php echo $row['amount_remaining']; ?>
                    </td>
                    <td>
                        <?php echo $row['pay_type']; ?>
                    </td>
                    <td>
                        <?php echo $row['number_litters']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_pay_type() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from pay_type";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> name </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['name']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_export() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from export";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> export_date </td>
                    <td> quantity </td>
                    <td> account </td>


                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['export_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['quantity']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_milk() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from milk";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> Type </td>
                    <td> cost </td>
                </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['type']; ?>
                    </td>
                    <td>
                        <?php echo $row['cost']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_profile() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from profile";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> name </td>
                    <td> last_name </td>
                    <td> gender </td>
                    <td> telphone </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['last_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['gender']; ?>
                    </td>
                    <td>
                        <?php echo $row['telphone']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function get_name_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select ,  account_category.account_category_id,  account_category.name";
        ?>
        <select class="textbox cbo_name"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_category_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select   account_category.account_category_id,  account_category.name from account_category";
        ?>
        <select class="textbox cbo_account_category"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_category_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_profile_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select   profile.profile_id,  profile.name from profile";
        ?>
        <select class="textbox cbo_name"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['profile_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select   account.account_id,  account.username from account";
        ?>
        <select class="textbox cbo_name"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['account_id'] . ">" . $row['username'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_milk_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select   milk.milk_id,  milk.type";
        ?>
        <select class="textbox cbo_name"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['milk_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_pay_type_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select   pay_type.pay_type_id,  pay_type.name";
        ?>
        <select class="textbox cbo_name"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['pay_type_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_account_category_id_by_account_category_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select   account_category.account_category_id   from account_category where account_category.name=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['account_category_id'];
        echo $userid;
    }

    //    get_account_category_id_by_account_category_name

    function get_nameid_by_name_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    name.name_id from name where name.namer=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name_id'];
        echo $userid;
    }

    function get_last_name_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select last_name.last_name_id,   last_name.name from last_name";
        ?>
        <select class="textbox cbo_last_name"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['last_name_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_last_nameid_by_last_name_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    last_name.last_name_id from last_name where last_name.namer=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['last_name_id'];
        echo $userid;
    }

    function get_milk_price($number) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select  milk.cost from milk limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['cost'];
        echo $userid * $number;
    }

    function get_last_profileid() {

        $db = new dbconnection();
        $sql = "select   profile.profile_id from profile order by profile_id desc limit 1";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['profile_id'];
        echo $userid;
    }

    function get_unconfirmed_export() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select export.export_id,  export.export_date,  export.quantity,  export.account,  export.receiver from export
                join account on export.account = account.account_id where receiver='0'";
        ?>
        <table class="new_data_table" style="margin-top: 0px;">
            <thead><tr>
                    <td> Delivery id </td>
                    <td> Delivery date </td>
                    <td> quantity </td>
                    <td> Activity </td>
                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['export_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['export_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['quantity']; ?>
                    </td>
                    <td>

                        <a class="inyange_confirm_link" style="color: #000080;" value="<?php echo $row['export_id']; ?>" href="#" >Confirm</a>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function get_total_milk_toPay() {
        $con = new dbconnection();
        $sql = "select  export.export_id,  sum(export.quantity) as tot from export 
            join account on export.account = account.account_id 
                           where  export.receiver <> '0'  ";
        $stmt = $con->openconnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $tot_received = $row['tot'];

        //this is the total quantity of milk paid

        $sql2 = "select    sum(payments.number_litters) as tot2  from payments   where   payments.pay_type = 'inyange' ";
        $stmt2 = $con->openconnection()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $tot_paid = $row2['tot2'];
        return $tot_received - $tot_paid;
    }

//this is the amount that inyange has to pay

    function get_confirmed_export() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select export.export_id,  export.export_date,  export.quantity,  export.account,  export.receiver from export
                join account on export.account = account.account_id where receiver<>'0'";
        ?>
        <table class="new_data_table" style="margin-top: 0px;">
            <thead><tr>
                    <td> Delivery id </td>
                    <td> Delivery date </td>
                    <td> quantity </td>

                </tr>
            </thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td>
                        <?php echo $row['export_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['export_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['quantity']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function get_total_available_milk() {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = " select sum(delivery.quantity)as qty  from delivery ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['qty'];

        $sql2 = " select sum(export.quantity)as qty2  from export ";
        $stmt2 = $db->openConnection()->prepare($sql2);
        $stmt2->execute();
        $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
        $userid2 = $row2['qty2'];
        $diff = $userid - $userid2;

        return $diff;
    }

    function get_selectable_profile() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from profile";
        ?>           
        <table class="new_data_table" style="margin-top: 0px;">
            <thead><tr>
                    <td> ID </td>
                    <td> name </td>
                    <td> last_name </td>
                    <td> gender </td>
                    <td> telphone </td>
                    <td> Option </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['profile_id']; ?>
                    </td>
                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['last_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['gender']; ?>
                    </td>
                    <td>
                        <?php echo $row['telphone']; ?>
                    </td>
                    <td>
                        <a href="#" class="select_link_agents" value=" 
                           <?php echo $row['profile_id']; ?>" style="color: #000080;">Select</a>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function get_selectable_profile_for_search() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from profile";
        ?>           
        <table class="new_data_table" style="margin-top: 0px;">
            <thead>
                <tr>
                    <td> ID </td>
                    <td> name </td>
                    <td> last_name </td>
                    <td> gender </td>
                    <td> telphone </td>
                    <td> Option </td>
                </tr>
            </thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td class="profile_col">
                        <?php echo $row['profile_id']; ?>
                    </td>
                    <td class="f_name_col">
                        <?php echo $row['name']; ?>
                    </td>
                    <td class="f_surname_col">
                        <?php echo $row['last_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['gender']; ?>
                    </td>
                    <td>
                        <?php echo $row['telphone']; ?>
                    </td>
                    <td>
                        <a href="#" class="select_link_search" value=" 
                           <?php echo $row['profile_id']; ?>" style="color: #000080;">Select</a>
                    </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function get_grouped_delivery() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select profile.profile_id, delivery.delivery_id, 
            delivery.profile,  delivery.account, 
            delivery.milk, sum(  delivery.quantity) as qty, 
            profile.name,  profile.last_name,profile.telphone,profile.gender, delivery.date
            from delivery
            join profile on delivery.profile = profile.profile_id 
            join account on delivery.account = account.account_id 
            group by profile_id ";
        ?>
        <table class="new_data_table" style="margin-top: 0px;">
            <thead>
                <tr>
                    <td> delivery_id </td>

                    <td> quantity </td>
                    <td> name </td>
                    <td> last_name </td>
                    <td> Telephone </td>
                    <td> gender </td>
                    <td> date </td>
                </tr></thead>
            <?php foreach ($db->query($sql) as $row) { ?><tr> 
                    <td><?php echo $row['delivery_id']; ?> </td>

                    <td><?php echo $row['qty']; ?> </td>
                    <td><?php echo $row['name']; ?> </td>
                    <td><?php echo $row['last_name']; ?> </td>
                    <td><?php echo $row['telphone']; ?> </td>
                    <td><?php echo $row['gender']; ?> </td>
                    <td><?php echo $row['date']; ?> </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function get_delivery_by_agent($profile_id, $date) {
        require_once('../web_db/connection.php');
        $con = new dbconnection();
        $sql = "select delivery.delivery_id,  delivery.date,  delivery.profile,  delivery.account,
                delivery.milk,  delivery.quantity,  profile.name,  profile.last_name,  profile.gender,  profile.telphone
                from delivery
                join profile on delivery.profile = profile.profile_id                                
               where   profile.profile_id =:profile   and delivery.date=:date   ";
        $stmt = $con->openConnection()->prepare($sql);
        $stmt->execute(array(":profile" => $profile_id, ":date" => $date));
        ?>
        <table class="new_data_table" style="margin-top: 0px;">
            <thead><tr>
                    <td> delivery_id </td><td> date </td><td> profile </td>
                    <td> account </td><td> milk </td>
                    <td> quantity </td><td> name </td>
                    <td> last_name </td><td> gender </td>
                    <td> telephone </td>
                </tr></thead>
            <?php while ($row = $stmt->fetch()) {
                ?><tr> 
                    <td> <?php echo $row['delivery_id']; ?> </td>
                    <td> <?php echo $row['date']; ?> </td>
                    <td> <?php echo $row['profile']; ?> </td>
                    <td> <?php echo $row['account']; ?> </td>
                    <td> <?php echo $row['milk']; ?> </td>
                    <td> <?php echo $row['quantity']; ?> </td>
                    <td> <?php echo $row['name']; ?> </td>
                    <td> <?php echo $row['last_name']; ?> </td>
                    <td> <?php echo $row['gender']; ?> </td>
                    <td> <?php echo $row['telphone']; ?> </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function get_delivery_by_date($date) {
        require_once('../web_db/connection.php');
        $con = new dbconnection();
        $sql = "select delivery.delivery_id,  delivery.date,  delivery.profile,  delivery.account,
                delivery.milk,  delivery.quantity,  profile.name,  profile.last_name,  profile.gender,  profile.telphone
                from delivery
                join profile on delivery.profile = profile.profile_id                                
               where   delivery.date=:date   ";
        $stmt = $con->openConnection()->prepare($sql);
        $stmt->execute(array(":date" => $date));
        ?>
        <table class="new_data_table" style="margin-top: 0px;">
            <thead><tr>
                    <td> delivery_id </td><td> date </td><td> profile </td>
                    <td> account </td><td> milk </td>
                    <td> quantity </td><td> name </td>
                    <td> last_name </td><td> gender </td>
                    <td> telephone </td>
                </tr></thead>
            <?php while ($row = $stmt->fetch()) {
                ?><tr> 
                    <td> <?php echo $row['delivery_id']; ?> </td>
                    <td> <?php echo $row['date']; ?> </td>
                    <td> <?php echo $row['profile']; ?> </td>
                    <td> <?php echo $row['account']; ?> </td>
                    <td> <?php echo $row['milk']; ?> </td>
                    <td> <?php echo $row['quantity']; ?> </td>
                    <td> <?php echo $row['name']; ?> </td>
                    <td> <?php echo $row['last_name']; ?> </td>
                    <td> <?php echo $row['gender']; ?> </td>
                    <td> <?php echo $row['telphone']; ?> </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function get_delivery_by_month($month) {
        require_once('../web_db/connection.php');
        $con = new dbconnection();
        $sql = "select delivery.delivery_id,  delivery.date,  delivery.profile,  delivery.account,
                delivery.milk,  delivery.quantity,  profile.name,  profile.last_name,  profile.gender,  profile.telphone
                from delivery
                join profile on delivery.profile = profile.profile_id                                
               where  month( delivery.date)=:date   ";
        $stmt = $con->openConnection()->prepare($sql);
        $stmt->execute(array(":date" => $month));
        ?>
        <table class="new_data_table" style="margin-top: 0px;">
            <thead><tr>
                    <td> delivery_id </td>
                    <td> date </td>
                    <td> quantity </td><td> name </td>
                    <td> last_name </td><td> gender </td>
                    <td> telephone </td>
                </tr></thead>
            <?php while ($row = $stmt->fetch()) {
                ?><tr> 
                    <td> <?php echo $row['delivery_id']; ?> </td>
                    <td> <?php echo $row['date']; ?> </td>

                    <td> <?php echo $row['quantity']; ?> </td>
                    <td> <?php echo $row['name']; ?> </td>
                    <td> <?php echo $row['last_name']; ?> </td>
                    <td> <?php echo $row['gender']; ?> </td>
                    <td> <?php echo $row['telphone']; ?> </td>
                </tr>
            <?php } ?></table>
        <?php
    }

    function get_delivery_by_year($month) {
        require_once('../web_db/connection.php');
        $con = new dbconnection();
        $sql = "select delivery.delivery_id,  delivery.date,  delivery.profile,  delivery.account,
                delivery.milk,  delivery.quantity,  profile.name,  profile.last_name,  profile.gender,  profile.telphone
                from delivery
                join profile on delivery.profile = profile.profile_id                                
               where  year( delivery.date)=:date   ";
        $stmt = $con->openConnection()->prepare($sql);
        $stmt->execute(array(":date" => $month));
        ?>
        <table class="new_data_table" style="margin-top: 0px;">
            <thead><tr>
                    <td> delivery_id </td>
                    <td> date </td>
                    <td> quantity </td><td> name </td>
                    <td> last_name </td><td> gender </td>
                    <td> telephone </td>
                </tr></thead>
            <?php while ($row = $stmt->fetch()) {
                ?><tr> 
                    <td> <?php echo $row['delivery_id']; ?> </td>
                    <td> <?php echo $row['date']; ?> </td>

                    <td> <?php echo $row['quantity']; ?> </td>
                    <td> <?php echo $row['name']; ?> </td>
                    <td> <?php echo $row['last_name']; ?> </td>
                    <td> <?php echo $row['gender']; ?> </td>
                    <td> <?php echo $row['telphone']; ?> </td>
                </tr>
            <?php } ?></table>
        <?php
    }

}

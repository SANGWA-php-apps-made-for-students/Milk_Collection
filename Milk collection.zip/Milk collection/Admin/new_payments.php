<?php
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_payments'])){

$date = $_POST['txt_date'];
$amount_due = $_POST['txt_amount_due'];
$amount_paid = $_POST['txt_amount_paid'];
$amount_remaining = $_POST['txt_amount_remaining'];
$pay_type = $_POST['txt_pay_type_id'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_payments($date, $amount_due, $amount_paid, $amount_remaining, $pay_type);
}
?>

 <html>
<head>
<title>
payments</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_payments.php" method="post" enctype="multipart/form-data">


<input type="hidden" id="txt_pay_type_id"   name="txt_pay_type_id"/>
      <?php
            include 'payments_header.php';
                ?>

<div class="parts eighty_centered">
 payments saved successfully!</div>

<div class="parts eighty_centered">
<div class="parts eighty_centered ">  payments</div>
 <table class="new_data_table">


<tr><td>date :</td><td> <input type="text"     name="txt_date" required class="textbox" />  </td></tr>
<tr><td>amount_due :</td><td> <input type="text"     name="txt_amount_due" required class="textbox" />  </td></tr>
<tr><td>amount_paid :</td><td> <input type="text"     name="txt_amount_paid" required class="textbox" />  </td></tr>
<tr><td>amount_remaining :</td><td> <input type="text"     name="txt_amount_remaining" required class="textbox" />  </td></tr>
 <tr><td>pay_type :</td><td> <?php get_pay_type_combo(); ?>  </td></tr>

<tr><td colspan="2"> <input type="submit" class="button" name="send_payments" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered" >
<?php 
 require_once '../web_db/multi_values.php';
 $obj = new multi_values();
$obj->list_payments(); 
?>

</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php
function get_pay_type_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_pay_type_in_combo();
}

<?php
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_account'])){

$username = $_POST['txt_username'];
$password = $_POST['txt_password'];
$account_category = $_POST['txt_account_category_id'];
$profile = $_POST['txt_profile_id'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_account($username, $password, $account_category, $profile);
}
?>

 <html>
<head>
<title>
account</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_account.php" method="post" enctype="multipart/form-data">


<input type="hidden" id="txt_account_category_id"   name="txt_account_category_id"/>
<input type="hidden" id="txt_profile_id"   name="txt_profile_id"/>
      <?php
            include 'account_header.php';
                ?>

<div class="parts eighty_centered">
 account saved successfully!</div>

<div class="parts eighty_centered">
<div class="parts eighty_centered ">  account</div>
 <table class="new_data_table">


<tr><td>username :</td><td> <input type="text"     name="txt_username" required class="textbox" />  </td></tr>
<tr><td>password :</td><td> <input type="text"     name="txt_password" required class="textbox" />  </td></tr>
 <tr><td>account_category :</td><td> <?php get_account_category_combo(); ?>  </td></tr> <tr><td>profile :</td><td> <?php get_profile_combo(); ?>  </td></tr>

<tr><td colspan="2"> <input type="submit" class="button" name="send_account" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered" >
<?php 
 require_once '../web_db/multi_values.php';
 $obj = new multi_values();
$obj->list_account(); 
?>

</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php
function get_account_category_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_account_category_in_combo();
}
function get_profile_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_profile_in_combo();
}

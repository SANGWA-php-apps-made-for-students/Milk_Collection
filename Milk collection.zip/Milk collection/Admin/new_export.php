<?php
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_export'])){

$export_date = $_POST['txt_export_date'];
$quantity = $_POST['txt_quantity'];
$account = $_POST['txt_account_id'];
$receiver = $_POST['txt_receiver_id'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_export($export_date, $quantity, $account, $receiver);
}
?>

 <html>
<head>
<title>
export</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_export.php" method="post" enctype="multipart/form-data">


<input type="hidden" id="txt_account_id"   name="txt_account_id"/><input type="hidden" id="txt_receiver_id"   name="txt_receiver_id"/>
      <?php
            include 'export_header.php';
                ?>

<div class="parts eighty_centered">
 export saved successfully!</div>

<div class="parts eighty_centered">
<div class="parts eighty_centered ">  export</div>
 <table class="new_data_table">


<tr><td>export_date :</td><td> <input type="text"     name="txt_export_date" required class="textbox" />  </td></tr>
<tr><td>quantity :</td><td> <input type="text"     name="txt_quantity" required class="textbox" />  </td></tr>
 <tr><td>account :</td><td> <?php get_account_combo(); ?>  </td></tr> <tr><td>receiver :</td><td> <?php get_receiver_combo(); ?>  </td></tr>

<tr><td colspan="2"> <input type="submit" class="button" name="send_export" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered" >
<?php 
 require_once '../web_db/multi_values.php';
 $obj = new multi_values();
$obj->list_export(); 
?>

</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php
function get_account_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_account_in_combo();
}<?php
function get_receiver_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_receiver_in_combo();
}

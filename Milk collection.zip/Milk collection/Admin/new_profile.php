<?php
if (!isset($_SESSION)) {     session_start();
}if (!isset($_SESSION['login_token'])) {
    header('location:../index.php');
         }
 if(isset($_POST['send_profile'])){

$name = $_POST['txt_name_id'];
$last_name = $_POST['txt_last_name_id'];
$gender = $_POST['txt_gender'];
$telphone = $_POST['txt_telphone'];

require_once '../web_db/new_values.php';
 $obj = new new_values();
$obj->new_profile($name, $last_name, $gender, $telphone);
}
?>

 <html>
<head>
<title>
profile</title>
      <link href="web_style/styles.css" rel="stylesheet" type="text/css"/>
        <link href="web_style/StylesAddon.css" rel="stylesheet" type="text/css"/></head>   <body>
        <form action="new_profile.php" method="post" enctype="multipart/form-data">


<input type="hidden" id="txt_name_id"   name="txt_name_id"/><input type="hidden" id="txt_last_name_id"   name="txt_last_name_id"/>
      <?php
            include 'profile_header.php';
                ?>

<div class="parts eighty_centered">
 profile saved successfully!</div>

<div class="parts eighty_centered">
<div class="parts eighty_centered ">  profile</div>
 <table class="new_data_table">


 <tr><td>name :</td><td> <?php get_name_combo(); ?>  </td></tr> <tr><td>last_name :</td><td> <?php get_last_name_combo(); ?>  </td></tr><tr><td>gender :</td><td> <input type="text"     name="txt_gender" required class="textbox" />  </td></tr>
<tr><td>telphone :</td><td> <input type="text"     name="txt_telphone" required class="textbox" />  </td></tr>


<tr><td colspan="2"> <input type="submit" class="button" name="send_profile" value="Save"/>  </td></tr>
</table>
</div>

<div class="parts eighty_centered" >
<?php 
 require_once '../web_db/multi_values.php';
 $obj = new multi_values();
$obj->list_profile(); 
?>

</div>  
</form>
    <script src="../web_scripts/jquery-2.1.3.min.js" type="text/javascript"></script>
    <script src="../web_scripts/web_scripts.js" type="text/javascript"></script>

<div class="parts eighty_centered footer"> Copyrights <?php echo date("Y") ?></div>
</body>
</hmtl>
<?php
function get_name_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_name_in_combo();
}<?php
function get_last_name_combo() {
    include '../web_db/multi_values.php';
    $obj = new multi_values();
    $obj->get_last_name_in_combo();
}

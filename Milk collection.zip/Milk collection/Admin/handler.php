<?php

if (isset($_POST['cbo_account_category'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_category_id_by_account_category_name();
    return $id;
}if (isset($_POST['cbo_profile'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_id_by_profile_name();
    return $id;
}if (isset($_POST['cbo_profile'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_profile_id_by_profile_name();
    return $id;
}if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name();
    return $id;
}if (isset($_POST['cbo_milk'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_milk_id_by_milk_name();
    return $id;
}if (isset($_POST['cbo_pay_type'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_pay_type_id_by_pay_type_name();
    return $id;
}if (isset($_POST['cbo_account'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_account_id_by_account_name();
    return $id;
}if (isset($_POST['cbo_receiver'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_receiver_id_by_receiver_name();
    return $id;
}if (isset($_POST['cbo_name'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_name_id_by_name_name();
    return $id;
}if (isset($_POST['cbo_last_name'])) {
    require_once '../web_db/multi_values.php';
    $obj = new multi_values();
    $id = $obj->get_last_name_id_by_last_name_name();
    return $id;
}

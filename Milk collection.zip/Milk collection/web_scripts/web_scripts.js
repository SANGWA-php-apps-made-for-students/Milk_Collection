$(document).ready(function () {

        get_account_category_id_combo();        get_profile_id_combo();        get_profile_id_combo();        get_account_id_combo();        get_milk_id_combo();        get_pay_type_id_combo();        get_account_id_combo();        get_receiver_id_combo();        get_name_id_combo();        get_last_name_id_combo();
function get_account_category_id_combo() {
    try {
        $('.cbo_account_category').change(function () {
            var cbo_account_category = $('.cbo_account_category option:selected').text();
            $.post('../Admin/handler.php', {cbo_account_category: cbo_account_category}, function (data) {
                $('#txt_account_category_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').text();
            $.post('../Admin/handler.php', {cbo_profile: cbo_profile}, function (data) {
                $('#txt_profile_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_profile_id_combo() {
    try {
        $('.cbo_profile').change(function () {
            var cbo_profile = $('.cbo_profile option:selected').text();
            $.post('../Admin/handler.php', {cbo_profile: cbo_profile}, function (data) {
                $('#txt_profile_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').text();
            $.post('../Admin/handler.php', {cbo_account: cbo_account}, function (data) {
                $('#txt_account_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_milk_id_combo() {
    try {
        $('.cbo_milk').change(function () {
            var cbo_milk = $('.cbo_milk option:selected').text();
            $.post('../Admin/handler.php', {cbo_milk: cbo_milk}, function (data) {
                $('#txt_milk_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_pay_type_id_combo() {
    try {
        $('.cbo_pay_type').change(function () {
            var cbo_pay_type = $('.cbo_pay_type option:selected').text();
            $.post('../Admin/handler.php', {cbo_pay_type: cbo_pay_type}, function (data) {
                $('#txt_pay_type_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_account_id_combo() {
    try {
        $('.cbo_account').change(function () {
            var cbo_account = $('.cbo_account option:selected').text();
            $.post('../Admin/handler.php', {cbo_account: cbo_account}, function (data) {
                $('#txt_account_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_receiver_id_combo() {
    try {
        $('.cbo_receiver').change(function () {
            var cbo_receiver = $('.cbo_receiver option:selected').text();
            $.post('../Admin/handler.php', {cbo_receiver: cbo_receiver}, function (data) {
                $('#txt_receiver_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_name_id_combo() {
    try {
        $('.cbo_name').change(function () {
            var cbo_name = $('.cbo_name option:selected').text();
            $.post('../Admin/handler.php', {cbo_name: cbo_name}, function (data) {
                $('#txt_name_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}function get_last_name_id_combo() {
    try {
        $('.cbo_last_name').change(function () {
            var cbo_last_name = $('.cbo_last_name option:selected').text();
            $.post('../Admin/handler.php', {cbo_last_name: cbo_last_name}, function (data) {
                $('#txt_last_name_id').val(data);
            });
        });
    } catch (err) {
        alert(err.message);
    }
}


});


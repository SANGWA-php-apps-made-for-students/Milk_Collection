<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Home</title>
        <link href="web_styles/web_.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        
       
            <?php
            include 'header_menu.php';
            ?>
    
        <div class="parts" id="contents">
            <a href="login.php">Login</a>
        </div>
    </body>
</html>

<?php
require_once '../web_db/connection.php';

class multi_values {

    function list_account() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> username </td>
                    <td> password </td>
                    <td> account_category </td>
                    <td> profile </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['username']; ?>
                    </td>
                    <td>
                        <?php echo $row['password']; ?>
                    </td>
                    <td>
                        <?php echo $row['account_category']; ?>
                    </td>
                    <td>
                        <?php echo $row['profile']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_account_category() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from account_category";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> name </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['name']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_delivery() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from delivery";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> date </td>
                    <td> profile </td>
                    <td> account </td>
                    <td> milk </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['profile']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>
                    <td>
                        <?php echo $row['milk']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_payments() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from payments";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> date </td>
                    <td> amount_due </td>
                    <td> amount_paid </td>
                    <td> amount_remaining </td>
                    <td> pay_type </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['date']; ?>
                    </td>
                    <td>
                        <?php echo $row['amount_due']; ?>
                    </td>
                    <td>
                        <?php echo $row['amount_paid']; ?>
                    </td>
                    <td>
                        <?php echo $row['amount_remaining']; ?>
                    </td>
                    <td>
                        <?php echo $row['pay_type']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_pay_type() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from pay_type";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> name </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['name']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_export() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from export";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> export_date </td>
                    <td> quantity </td>
                    <td> account </td>
                    <td> receiver </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['export_date']; ?>
                    </td>
                    <td>
                        <?php echo $row['quantity']; ?>
                    </td>
                    <td>
                        <?php echo $row['account']; ?>
                    </td>
                    <td>
                        <?php echo $row['receiver']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_milk() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from milk";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> cost_per_litter </td>
                    <td> type </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['cost_per_litter']; ?>
                    </td>
                    <td>
                        <?php echo $row['type']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function list_profile() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select * from profile";
        ?>
        <table class="new_data_table">
            <thead><tr>
                    <td> name </td>
                    <td> last_name </td>
                    <td> gender </td>
                    <td> telphone </td>

                </tr></thead>

            <?php foreach ($db->query($sql) as $row) { ?><tr> 

                    <td>
                        <?php echo $row['name']; ?>
                    </td>
                    <td>
                        <?php echo $row['last_name']; ?>
                    </td>
                    <td>
                        <?php echo $row['gender']; ?>
                    </td>
                    <td>
                        <?php echo $row['telphone']; ?>
                    </td>

                </tr>
            <?php } ?></table>
        <?php
    }

    function get_name_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select name.name_id,   name.name from name";
        ?>
        <select class="textbox cbo_name"><option></option>
            <?php
            foreach ($db->query($sql) as $row) {
                echo "<option value=" . $row['name_id'] . ">" . $row['name'] . " </option>";
            }
            ?>
        </select>
        <?php
    }

    function get_nameid_by_name_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    name.name_id from name where name.namer=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['name_id'];
        echo $userid;
    }

    function get_last_name_in_combo() {
        require_once('../web_db/connection.php');
        $database = new dbconnection();
        $db = $database->openConnection();
        $sql = "select last_name.last_name_id,   last_name.name from last_name";
        ?>
        <select class="textbox cbo_last_name"><option></option>
                <?php
                foreach ($db->query($sql) as $row) {
                    echo "<option value=" . $row['last_name_id'] . ">" . $row['name'] . " </option>";
                }
                ?>
        </select>
        <?php
    }

    function get_last_nameid_by_last_name_name($name) {
        require_once('../web_db/connection.php');
        $db = new dbconnection();
        $sql = "select    last_name.last_name_id from last_name where last_name.namer=:name ";
        $stmt = $db->openConnection()->prepare($sql);
        $stmt->bindValue(':name', $name);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $userid = $row['last_name_id'];
        echo $userid;
    }

}

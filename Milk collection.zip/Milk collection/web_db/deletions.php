<?php 
class deletions{


 function deleteFrom_account( $account_id){
$con = new dbconnection();
$con->con_users();
$query="delete from account where account_id ='$account_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_account_category( $account_category_id){
$con = new dbconnection();
$con->con_users();
$query="delete from account_category where account_category_id ='$account_category_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_delivery( $delivery_id){
$con = new dbconnection();
$con->con_users();
$query="delete from delivery where delivery_id ='$delivery_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_payments( $payments_id){
$con = new dbconnection();
$con->con_users();
$query="delete from payments where payments_id ='$payments_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_pay_type( $pay_type_id){
$con = new dbconnection();
$con->con_users();
$query="delete from pay_type where pay_type_id ='$pay_type_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_export( $export_id){
$con = new dbconnection();
$con->con_users();
$query="delete from export where export_id ='$export_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_milk( $milk_id){
$con = new dbconnection();
$con->con_users();
$query="delete from milk where milk_id ='$milk_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


 function deleteFrom_profile( $profile_id){
$con = new dbconnection();
$con->con_users();
$query="delete from profile where profile_id ='$profile_id'";
mysql_query($query)or die(mysql_error());
echo 'Record removed succefully';


}


}


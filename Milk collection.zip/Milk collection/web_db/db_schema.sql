
--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
`account_id`     int(11) NOT NULL AUTO_INCREMENT 
,`username`     VARCHAR(60) 
,`password`     VARCHAR(60) 

,PRIMARY KEY (`account_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `account_category`
--

CREATE TABLE IF NOT EXISTS `account_category` (
`account_category_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`account_category_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `delivery`
--

CREATE TABLE IF NOT EXISTS `delivery` (
`delivery_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date`     Date 

,PRIMARY KEY (`delivery_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
`payments_id`     int(11) NOT NULL AUTO_INCREMENT 
,`date`     Date 

,PRIMARY KEY (`payments_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `pay_type`
--

CREATE TABLE IF NOT EXISTS `pay_type` (
`pay_type_id`     int(11) NOT NULL AUTO_INCREMENT 
,`name`     VARCHAR(60) 

,PRIMARY KEY (`pay_type_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `export`
--

CREATE TABLE IF NOT EXISTS `export` (
`export_id`     int(11) NOT NULL AUTO_INCREMENT 
,`export_date`     Date 

,PRIMARY KEY (`export_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `milk`
--

CREATE TABLE IF NOT EXISTS `milk` (
`milk_id`     int(11) NOT NULL AUTO_INCREMENT 
,`type`     VARCHAR(60) 

,PRIMARY KEY (`milk_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
`profile_id`     int(11) NOT NULL AUTO_INCREMENT 
,`gender`     VARCHAR(60) 
,`telphone`     VARCHAR(60) 
,`last_name`     VARCHAR(60) 

,PRIMARY KEY (`profile_id`)  ) 
ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


<?php
 require_once '../web_db/connection.php'; 
class multi_values{


 function update_account( $username, $password, $account_category, $profile){
$con = new dbconnection();
$con->con_users();

$query="update account  set username= '$username', password= '$password', account_category= '$account_category', profile= '$profile'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_account_category( $name){
$con = new dbconnection();
$con->con_users();

$query="update account_category  set name= '$name'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_delivery( $date, $profile, $account, $milk){
$con = new dbconnection();
$con->con_users();

$query="update delivery  set date= '$date', profile= '$profile', account= '$account', milk= '$milk'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_payments( $date, $amount_due, $amount_paid, $amount_remaining, $pay_type){
$con = new dbconnection();
$con->con_users();

$query="update payments  set date= '$date', amount_due= '$amount_due', amount_paid= '$amount_paid', amount_remaining= '$amount_remaining', pay_type= '$pay_type'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_pay_type( $name){
$con = new dbconnection();
$con->con_users();

$query="update pay_type  set name= '$name'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_export( $export_date, $quantity, $account, $receiver){
$con = new dbconnection();
$con->con_users();

$query="update export  set export_date= '$export_date', quantity= '$quantity', account= '$account', receiver= '$receiver'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_milk( $cost_per_litter, $type){
$con = new dbconnection();
$con->con_users();

$query="update milk  set cost_per_litter= '$cost_per_litter', type= '$type'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}
 function update_profile( $name, $last_name, $gender, $telphone){
$con = new dbconnection();
$con->con_users();

$query="update profile  set name= '$name', last_name= '$last_name', gender= '$gender', telphone= '$telphone'";
mysql_query($query)or die(mysql_error());
echo 'data saved succefully';


}

}

